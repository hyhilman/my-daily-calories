<div class="bgimg-3 w3-container w3-pale-green" id="contact">
          <div class="w3-container w3-teal">
              <h3><i class="w3-margin-right w3-wide"></i>Hasil Susunan Komposisi Makanan</h3>
          </div>
   <div class="w3-row">
          <div class="w3-row w3-container w3-card-4 w3-white" style="padding-bottom: 50px">
            <center>
              <div class="w3-col" style="width:18%;height:50px;margin-right: 10px">
                  <p> Nama Makanan </p>
              </div>
              <div class="w3-col" style="width:18%;height: 50px;margin-right: 10px">
                  <p> Berat Makanan (gr) </p>
              </div>
              <div class="w3-col" style="width:18%;height: 50px;margin-right: 10px">
                  <p> Kalori/Gram </p>
              </div>
              <div class="w3-col" style="width:18%;height: 50px;margin-right: 10px">
                  <p> Total Kalori </p>
              </div>
              <div class="w3-col" style="width:18%;margin-right: 10px">
                <p> Tukar Makanan </p>
              </div>  
            </center>

          <!-- ISI HASIL  --> 
              <div class="w3-col w3-container w3-pale-green" style="width:18%;height:50px;margin-right: 10px">
                  <p> TEST </p>
              </div>
              <div class="w3-col w3-container w3-pale-green" style="width:18%;height: 50px;margin-right: 10px">
                  <p> TEST </p>
              </div>
              <div class="w3-col w3-container w3-pale-green" style="width:18%;height: 50px;margin-right: 10px">
                  <p> TEST </p>
              </div>
              <div class="w3-col w3-container w3-pale-green" style="width:18%;height: 50px;margin-right: 10px">
                  <p> TEST </p>
              </div>
              <div class="w3-col " style="width:18%">
                <select class="w3-select w3-border  w3-green" style="height:50px">
                  <option value="" disabled selected>Tukar Makanan</option>
                    <optgroup label="Karbohidrat">
                        <option>Nasi</option>
                        <option>Kentang</option>
                        <option>Ubi</option>
                        <option>Beras Merah</option>
                        <option>Ketan Hitam</option>
                        <option>Pasta</option>
                        <option>Roti</option>
                        <option>Mie</option>  
                        <option>Jagung</option>
                        <option>Sereal</option>
                    </optgroup>
                    <optgroup label="Proten">
                        <option>Daging Sapi</option>
                        <option>Daging Ayam</option>
                        <option>Daging Kambing</option>
                        <option>Telur Ayam</option>
                        <option>Ikan Laut</option>
                        <option>Kepiting</option>
                        <option>Tahu</option>
                        <option>Tempe</option>
                        <option>Jamur</option>
                        <option>Ikan Tuna</option>
                        <option>Ikan Lele</option>  
                        <option>Keju</option>
                        <option>Susu Sapi</option>
                    </optgroup>
                    <optgroup label="Lemak">
                        <option>Item 3</option>
                        <option>Item 4</option> 
                    </optgroup>
                </select>
              </div>  
          </div>
    </div>
  </div>