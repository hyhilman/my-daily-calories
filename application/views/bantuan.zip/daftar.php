<div class="bgimg-3 w3-container w3-padding-32 w3-white" id="contact">
    <div class="w3-rows w3-padding-xxlarge">
        <div class="w3-col m5  w3-container">
              <div><span class="w3-xlarge w3-border-teal w3-bottombar">Member My Daily Calories</span></div>
              <p>Bergabung menjadi member dan dapatkan fitur-fitur ini</p>
              <ul class="w3-ul" style="width: 350px">
                <li><i class="fa fa-check" style="font-size:24px;color:teal;"></i> Hitung Kalori Makanan</li>
                <li><i class="fa fa-check" style="font-size:24px;color:teal;"></i> Menyusun Komposisi Makanan</li>
                <li><i class="fa fa-check" style="font-size:24px;color:teal;"></i> Mendapat Saran Komposisi Makanan</li>
              </ul>
        </div>

        <!-- form daftar -->
        <div class="w3-col m5">
          <div class="w3-container w3-center w3-teal">
              <h3><i class="w3-margin-right w3-wide"></i>Daftar Member My Daily Calories</h3>
          </div>
            <form class="w3-container w3-card-4 w3-pale-green" style="padding-bottom: 20px" action="form.asp" target="_blank">
                  <label class="">Name</label>
                  <input class="w3-input w3-border" type="text" name="Name" placeholder="Masukkan Nama" style="width:350px" required> <br>
                  <label >Email</label>
                  <input class="w3-input w3-border" type="text" name="Email" placeholder="Masukkan Email" style="width:350px" required ><br>
                  <label >Tanggal Lahir</label>
                  <input class="w3-input w3-border" type="date" name="tanggalLahir"   style="width:350px" required> <br>
                  <label >Password</label>
                  <input class="w3-input w3-border" type="password" name="password" placeholder="Masukkan Password" style="width:350px" required> <br>
                  <!-- <label >Password</label> -->
                  <input class="w3-input w3-border" type="password" name="password" placeholder="Masukkan Kembali Password" style="width:350px" required> <br>
                
                <button type="submit" class="w3-btn w3-large w3-green" style="width: 120px">Daftar</button>
            </form>
        </div>  
    </div>
  </div>