  <div class="bgimg-3 w3-container w3-padding-64 w3-camo-olive >
    <div class="w3-rows w3-padding-xxlarge">
      <div class="w3-col" style="padding:20px 420px;">
      <div class="w3-container w3-teal w3-padding w3-center w3-xlarge"> Masuk My Daily Calories </div>
            <form class="w3-container w3-card-2 w3-padding w3-white" method="post">
              <div class="w3-section">
                <center>
                  <label><b>Username</b></label>
                  <input class="w3-input w3-border w3-margin-bottom" type="text" placeholder="Username / Email" name="username_mail" required style="width:300px">
                  <label><b>Password</b></label>
                  <input class="w3-input w3-border" type="password" placeholder="Password" name="password" required style="width:300px">
                  <button class="w3-btn-block w3-green w3-section w3-padding" type="submit" style="width:300px">Masuk</button><br>w
                 
                  </center>
               </div>
            </form>
      </div>

    </div>
  </div>
