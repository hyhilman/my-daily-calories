
</div>
</div>

<!-- Saran Komposisi -->
<div class="w3-teal w3-container w3-center" style="height:250px">
    <div class=" w3-content w3-teal" style="padding-right: 30px;margin-top:20px;padding-bottom: 10px; width: 700px">
        <h2 class="w3-bottombar"> SARAN KOMPOSISI MAKANAN </h2> 
		<?php if( null ===($this->session->userdata('username')) ):?>
		<p>Dapatkan susunan komposisi makanan yang disarankan untuk anda konsumsi dan ketahui informasi jumlah kalorinya. Anda harus menghitung kebutuhan kalori dan masuk sistem terlebih dahulu untuk mendapatkan saran komposisi.</p>
		<?php 
		echo '<form>';
		else: ?>
		<p><?=print_r($saran_makanan)?></p>
		<?php 
		$url_query = array();
		$counter = 1;
		foreach($saran_makanan as $row){
			$url_query['makanan_dipilih['.$counter.']'] = $row['id_makanan'];
			$url_query['berat['.$counter.']'] = $row['berat'];
			$counter++;
		}
		$url_query['hitung'] = 'true';

		echo '<form action="'.base_url().'/c_member/susun_makanan?'.http_build_query($url_query).'" method="post">';
		endif; 
		echo '<button type="submit" class="w3-btn w3-green w3-large">Saran Komposisi</button>';
		echo '</form>'
		?>
	</div>
</div>