  <!-- Image Header -->
<div class="bgimg-1 w3-display-container" >
  <div class="w3-display-middle w3-container w3-white w3-hover-black  w3-wide w3-animate-opacity"
    style="height:80px;opacity:0.9;width:50%">
    <h2 class="w3-center"><b>Bantuan</b></h2>
  </div>
</div>

<!-- Bantuan -->
  <div class="bgimg-3 w3-container w3-padding-64 w3-camo-olive ">
    
  </div>
