  <!-- Quotes -->
  <div class="bgimg-2 w3-container w3-padding-16 w3-center w3-wide" id="rsvp">
  	<div class="w3-panel w3-sand w3-center" style="width:70%;opacity:0.9;margin-left:200px">
  		<p class="w3-xxlarge w3-serif"><i>"When your body is hungry, it wants nutrients, not calories"</i></p>
  		<p class="w3-large">Anonymous</p>
  	</div>
  </div>