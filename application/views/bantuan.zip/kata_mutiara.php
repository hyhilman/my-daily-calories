    </div>
  </div>
  <div class="bgimg-2 w3-container w3-padding-16 w3-center w3-wide" id="rsvp">
  	<div class="w3-panel w3-sand w3-center" style="width:70%;opacity:0.9;margin-left:200px">
  		<p class="w3-xxlarge w3-serif"><i>"It's not about eating healthy to lose weight. It's about eating healthy to feel good"</i></p>
  		<p class="w3-large">Demi Lovato</p>
  	</div>
  </div>