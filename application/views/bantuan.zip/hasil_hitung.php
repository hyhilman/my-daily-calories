<div class="w3-half w3-panel w3-sand w3-card-2 w3-center w3-content w3-pale-green" style="width:500px;height:450px;opacity:0.9; margin-left:100px">
    <h2 class="w3-xlarge w3-bottombar w3-border-teal">Hasil Perhitungan Kalori</h2> <hr>
    <p class="w3-large">
    <?="Jumlah Energy yang anda butuhkan perhari adalah : ".$energy."<br>"?>
    <?="Jumlah Karbohidrat yang anda butuhkan perhari adalah : ".$karbo."<br>"?>
    <?="Jumlah Lemak yang anda butuhkan perhari adalah : ".$lemak."<br>"?>
    <?="Jumlah Protein yang anda butuhkan perhari adalah : ".$protein."<br>"?>
  </p>
</div>

