<div class="w3-half w3-container w3-center " style="height:400px">
      <div class="w3-teal w3-content" style="margin-top: 60px;margin-left: 150px;padding: 5px 30px 10px 30px; width: 500px">
            <h2 class="w3-bottombar">HITUNG KALORI SAYA</h2> 
            <p>Dapatkan informasi mengenai kebutuhan kalori harian anda sehingga anda bisa hidup lebih sehat tanpa kekurangan ataupun kelebihan kalori tiap harinya.</p>
      </div>
 </div>